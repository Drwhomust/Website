import tkinter as tk
from tkinter import scrolledtext, messagebox
import subprocess
import threading
import os

class CMDWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("CMD in Tkinter")
        self.root.geometry("800x600")
        
        # Create a frame for the output display
        output_frame = tk.Frame(root)
        output_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create a scrolled text widget to display command output
        self.output_text = scrolledtext.ScrolledText(
            output_frame,
            wrap=tk.WORD,
            bg="black",
            fg="white",
            font=("Courier", 10)
        )
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # Create a frame for the input
        input_frame = tk.Frame(root)
        input_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Create a label
        label = tk.Label(input_frame, text="Command:")
        label.pack(side=tk.LEFT, padx=5)
        
        # Create an entry widget for command input
        self.command_entry = tk.Entry(input_frame, font=("Courier", 10))
        self.command_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.command_entry.bind("<Return>", lambda event: self.execute_command())
        
        # Create a button to execute the command
        execute_button = tk.Button(input_frame, text="Execute", command=self.execute_command)
        execute_button.pack(side=tk.LEFT, padx=5)
        
        # Create a button to clear the output
        clear_button = tk.Button(input_frame, text="Clear", command=self.clear_output)
        clear_button.pack(side=tk.LEFT, padx=5)
        
        # Initialize the process variable
        self.process = None
        self.is_running = False
        
        # Display initial message
        self.output_text.insert(tk.END, "CMD Interface - Ready\n")
        self.output_text.insert(tk.END, "Type a command and press Enter or click Execute\n")
        self.output_text.insert(tk.END, "-" * 50 + "\n")
        
    def execute_command(self):
        """Execute the command entered in the entry widget"""
        command = self.command_entry.get()
        
        if not command.strip():
            messagebox.showwarning("Warning", "Please enter a command")
            return
        
        # Display the command being executed
        self.output_text.insert(tk.END, f"\n> {command}\n")
        self.output_text.see(tk.END)
        self.root.update()
        
        # Clear the entry widget
        self.command_entry.delete(0, tk.END)
        
        # Execute the command in a separate thread to avoid freezing the GUI
        thread = threading.Thread(target=self.run_command, args=(command,))
        thread.daemon = True
        thread.start()
    
    def run_command(self, command):
        """Run the command using subprocess"""
        try:
            self.is_running = True
            
            # Use shell=True to allow complex commands like 'dir', 'echo', etc.
            self.process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            # Read the output line by line
            while True:
                line = self.process.stdout.readline()
                if not line:
                    break
                
                # Insert the line into the text widget
                self.output_text.insert(tk.END, line)
                self.output_text.see(tk.END)
                self.root.update()
            
            # Wait for the process to complete
            self.process.wait()
            
            # Display the return code
            return_code = self.process.returncode
            self.output_text.insert(tk.END, f"\n[Process completed with return code: {return_code}]\n")
            self.output_text.see(tk.END)
            self.root.update()
            
        except Exception as e:
            self.output_text.insert(tk.END, f"\nError: {str(e)}\n")
            self.output_text.see(tk.END)
            self.root.update()
        
        finally:
            self.is_running = False
    
    def clear_output(self):
        """Clear the output text widget"""
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, "Output cleared\n")

def main():
    root = tk.Tk()
    app = CMDWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()
